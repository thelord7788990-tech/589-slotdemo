package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.SettingsState
import com.example.ui.components.CoinToggleSwitch
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoTealDark
import com.example.ui.theme.CasinoTealLight
import com.example.ui.theme.CasinoTealPrimary

@Composable
fun SettingsDialog(
    settings: SettingsState,
    onToggleMusic: () -> Unit,
    onToggleSound: () -> Unit,
    onToggleFx: () -> Unit,
    onToggleAnnouncements: () -> Unit,
    onOpenAdminConfig: () -> Unit,
    onResetDemo: () -> Unit,
    onClose: () -> Unit
) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xB3000000))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClose
                ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.68f)
                    .fillMaxHeight(0.85f)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
                    .testTag("settings_dialog_root")
            ) {
                // Teal / Dark Cyan Dialog Container
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 16.dp, end = 16.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(
                                    Color(0xFF004D40),
                                    Color(0xFF00382E),
                                    Color(0xFF00241E)
                                )
                            )
                        )
                        .border(
                            2.5.dp,
                            Brush.verticalGradient(
                                listOf(Color(0xFF26C6DA), Color(0xFF00838F), Color(0xFF004D40))
                            ),
                            RoundedCornerShape(14.dp)
                        )
                        .padding(horizontal = 24.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Title: "ဖွဲ့စည်းပုံ" (Configuration / Settings)
                    Text(
                        text = "ဖွဲ့စည်းပုံ",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )

                    // 4 Settings Rows
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(0.82f)
                            .padding(vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 1. Music ("တေးသီချင်း")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = "Music",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Text(
                                    text = "တေးသီချင်း",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            CoinToggleSwitch(
                                checked = settings.musicOn,
                                onCheckedChange = { onToggleMusic() }
                            )
                        }

                        // 2. Sound ("တေးသံ")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = "Sound",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Text(
                                    text = "တေးသံ",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            CoinToggleSwitch(
                                checked = settings.soundOn,
                                onCheckedChange = { onToggleSound() }
                            )
                        }

                        // 3. Special Effects ("အထူးသက်ရောက်မှု")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "FX",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Text(
                                    text = "အထူးသက်ရောက်မှု",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            CoinToggleSwitch(
                                checked = settings.fxOn,
                                onCheckedChange = { onToggleFx() }
                            )
                        }

                        // 4. Announcements ("ကြေငြာချက်")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Movie,
                                    contentDescription = "Announcements",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Text(
                                    text = "ကြေငြာချက်",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            CoinToggleSwitch(
                                checked = settings.announcementsOn,
                                onCheckedChange = { onToggleAnnouncements() }
                            )
                        }
                    }

                    // Admin Payment Settings demo link + Version info
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "v:1.0.113",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 11.sp
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Admin Payment Setting button
                            Box(
                                modifier = Modifier
                                    .height(26.dp)
                                    .background(Color(0xFF00695C), RoundedCornerShape(4.dp))
                                    .border(1.dp, CasinoGoldPrimary, RoundedCornerShape(4.dp))
                                    .clickable(onClick = onOpenAdminConfig)
                                    .padding(horizontal = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "ငွေပေးချေမှု Demo ပြင်ဆင်ရန်",
                                    color = CasinoGoldLight,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Reset Demo Data button
                            Box(
                                modifier = Modifier
                                    .height(26.dp)
                                    .background(Color(0xFF37474F), RoundedCornerShape(4.dp))
                                    .border(1.dp, Color.White, RoundedCornerShape(4.dp))
                                    .clickable(onClick = onResetDemo)
                                    .padding(horizontal = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Reset Demo",
                                    color = Color.White,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }

                // Cyan Circular Close Button Top Right
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(40.dp)
                        .shadow(4.dp, CircleShape)
                        .background(
                            brush = Brush.radialGradient(
                                listOf(Color(0xFF80DEEA), Color(0xFF00ACC1), Color(0xFF00838F))
                            ),
                            shape = CircleShape
                        )
                        .border(2.dp, Color.White, CircleShape)
                        .clickable(onClick = onClose)
                        .testTag("settings_close_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}
