package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.TempleRoofDialog
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoRedDark
import com.example.ui.theme.CasinoRedPrimary

/**
 * Screenshots 1, 2, 3: Bank Account Binding ("ဘဏ်အကောင့်")
 */
@Composable
fun BindBankAccountDialog(
    selectedBank: String,
    accountNumber: String,
    onSelectBank: (String) -> Unit,
    onAccountNumberChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onClose: () -> Unit
) {
    var expandedDropdown by remember { mutableStateOf(false) }

    TempleRoofDialog(
        title = "ဘဏ်အကောင့်",
        onClose = onClose,
        bottomActionText = "ချည်နှောင်ခြင်းပြီးပါပြီ",
        onBottomAction = onSubmit,
        modifier = Modifier.testTag("bind_bank_dialog_root")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Dropdown Selector with Chip Icon
            Row(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(38.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                // Gold Chip Icon
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(Color(0xFFFFF8E1), RoundedCornerShape(4.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("💳", fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Selector Box
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                        .clickable { expandedDropdown = true }
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = if (selectedBank.isNotEmpty()) selectedBank else "ဘဏ်အမည်ကို ရွေးပါ",
                        color = if (selectedBank.isNotEmpty()) CasinoGoldLight else Color.LightGray,
                        fontSize = 13.sp
                    )

                    DropdownMenu(
                        expanded = expandedDropdown,
                        onDismissRequest = { expandedDropdown = false },
                        modifier = Modifier.background(Color(0xFF330005))
                    ) {
                        DropdownMenuItem(
                            text = { Text("KBZ Pay", color = Color.White) },
                            onClick = {
                                onSelectBank("KBZ Pay")
                                expandedDropdown = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("WAVE Pay", color = Color.White) },
                            onClick = {
                                onSelectBank("WAVE Pay")
                                expandedDropdown = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Phone / Account number input
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(48.dp)
                    .background(Color(0xFF4A050A), RoundedCornerShape(4.dp))
                    .border(1.dp, CasinoRedPrimary, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                OutlinedTextField(
                    value = accountNumber,
                    onValueChange = onAccountNumberChange,
                    placeholder = {
                        Text(
                            text = "မိမိရဲ့ဘဏ်",
                            color = Color.LightGray,
                            fontSize = 14.sp,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    },
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

/**
 * Screenshot 8b: Bank Card Binding Dialog ("ဘဏ်ကတ်နှင့် ချည်နှောင်ပါ")
 */
@Composable
fun BindBankCardDialog(
    holderName: String,
    cardNumber: String,
    onHolderNameChange: (String) -> Unit,
    onCardNumberChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onClose: () -> Unit
) {
    TempleRoofDialog(
        title = "ဘဏ်ကတ်နှင့် ချည်နှောင်ပါ",
        onClose = onClose,
        bottomActionText = "ချည်ပါ",
        onBottomAction = onSubmit,
        modifier = Modifier.testTag("bind_bank_card_dialog_root")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Row 1: Name
            Row(
                modifier = Modifier.fillMaxWidth(0.9f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "နာမည်",
                    color = CasinoGoldLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(90.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    OutlinedTextField(
                        value = holderName,
                        onValueChange = onHolderNameChange,
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Row 2: Card / Account Number
            Row(
                modifier = Modifier.fillMaxWidth(0.9f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ဘဏ်ကတ်အကောင့်",
                    color = CasinoGoldLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(90.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    OutlinedTextField(
                        value = cardNumber,
                        onValueChange = onCardNumberChange,
                        placeholder = { Text("ကျေးဇူးပြု၍ အကောင့်နံပါတ်ထည့်ပါ", color = Color.Gray, fontSize = 11.sp) },
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Warning Notice
            Text(
                text = "ကျေးဇူးပြု၍ ဒက်ဘစ်ကတ်ကိုသုံးပါ။ ခရက်ဒစ်ကတ်မသုံးပါနှင့်။ ခရက်ဒစ်ကတ်သည် ပုံမှန်ငွေလက်ခံနိုင်ခြင်းမရှိပါ။",
                color = Color(0xFFFF5252),
                fontSize = 11.sp,
                lineHeight = 15.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(0.9f)
            )
        }
    }
}
