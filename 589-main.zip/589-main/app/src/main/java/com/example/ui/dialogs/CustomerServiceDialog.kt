package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.ui.components.GreenPillButton
import com.example.ui.components.PurplePillButton
import com.example.ui.components.TempleRoofDialog
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoRedBright
import com.example.ui.theme.CasinoRedDark
import com.example.ui.theme.CasinoRedPrimary

@Composable
fun CustomerServiceDialog(
    chatMessages: List<ChatMessage>,
    activeTab: Int,
    inputText: String,
    onTabSelect: (Int) -> Unit,
    onInputChange: (String) -> Unit,
    onSendMessage: () -> Unit,
    onPhotoClick: () -> Unit,
    onClose: () -> Unit
) {
    TempleRoofDialog(
        title = "ဖောက်သည် ဝန်ဆောင်မှုကိုဆက်သွယ်ပါ",
        onClose = onClose,
        modifier = Modifier.testTag("customer_service_dialog_root")
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Left Navigation Tabs
            Column(
                modifier = Modifier
                    .width(130.dp)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Tab 0: FAQ
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(34.dp)
                        .background(
                            if (activeTab == 0) Color(0xFF8B1A20) else Color(0xFF420205),
                            RoundedCornerShape(4.dp)
                        )
                        .border(1.dp, if (activeTab == 0) CasinoGoldPrimary else Color(0xFF6B1218), RoundedCornerShape(4.dp))
                        .clickable { onTabSelect(0) }
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "အမေးများသောမေးခွန်းများ",
                        color = if (activeTab == 0) CasinoGoldLight else Color.LightGray,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Tab 1: Online Customer Service (Active)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(34.dp)
                        .background(
                            if (activeTab == 1) {
                                Brush.verticalGradient(
                                    listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                                )
                            } else {
                                Brush.verticalGradient(
                                    listOf(Color(0xFF5A1418), Color(0xFF38080C))
                                )
                            },
                            RoundedCornerShape(4.dp)
                        )
                        .border(1.dp, Color.White, RoundedCornerShape(4.dp))
                        .clickable { onTabSelect(1) }
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "အွန်လိုင်းဖောက်သည် ဝန်ဆောင်မှု",
                        color = if (activeTab == 1) Color(0xFF3B1E00) else Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                // Tab 2: Feedback
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(34.dp)
                        .background(
                            if (activeTab == 2) Color(0xFF8B1A20) else Color(0xFF420205),
                            RoundedCornerShape(4.dp)
                        )
                        .border(1.dp, if (activeTab == 2) CasinoGoldPrimary else Color(0xFF6B1218), RoundedCornerShape(4.dp))
                        .clickable { onTabSelect(2) }
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "အကြံပြုချက်များတင်ပြပုံ",
                        color = if (activeTab == 2) CasinoGoldLight else Color.LightGray,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Right Pane: Chat Window / FAQ Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                if (activeTab == 0) {
                    // FAQ Content
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text("မေး: ဂိမ်းထဲငွေဘယ်လိုသွင်းရမလဲ?", color = CasinoGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("ဖြေ: 'ဖြည့်ပါ' ခလုတ်ကိုနှိပ်၍ KBZ Pay သို့မဟုတ် WavePay ရွေးချယ်ပြီး လွှဲပြောင်းနိုင်ပါသည်။", color = Color.White, fontSize = 11.sp)
                        }
                        item {
                            Text("မေး: ငွေထုတ်ယူမှု အနည်းဆုံးပမာဏ ဘယ်လောက်လဲ?", color = CasinoGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("ဖြေ: အနည်းဆုံး ၁၀,၀၀၀ ကျပ်မှစ၍ ထုတ်ယူနိုင်ပြီး လက်ကျန်ငွေ ၁,၀၀၀ ကျပ် ချန်ထားရပါမည်။", color = Color.White, fontSize = 11.sp)
                        }
                    }
                } else if (activeTab == 2) {
                    // Feedback Content
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("ဂိမ်းအတွေ့အကြုံအတွက် အကြံပြုချက်များ ပေးပို့နိုင်ပါသည်", color = CasinoGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("ကျွန်ုပ်တို့၏ ၂၄ နာရီ ဝန်ဆောင်မှုအဖွဲ့မှ လူကြီးမင်း၏ အကြံပြုချက်ကို လေးစားစွာ လက်ခံပါမည်။", color = Color.White, fontSize = 11.sp)
                    }
                } else {
                    // Chat Messages (Screenshot 15)
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                            .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(chatMessages) { msg ->
                            if (!msg.isUser) {
                                // CS Agent message
                                Column(
                                    modifier = Modifier.fillMaxWidth(0.95f),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFF3E0A0E), RoundedCornerShape(6.dp))
                                            .border(1.dp, Color(0xFF6B1A22), RoundedCornerShape(6.dp))
                                            .padding(8.dp)
                                    ) {
                                        Text(
                                            text = msg.text,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            lineHeight = 16.sp
                                        )
                                    }
                                    Text(
                                        text = msg.time,
                                        color = Color.Gray,
                                        fontSize = 9.sp,
                                        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                                    )
                                }
                            } else {
                                // User message with Avatar icon
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(CasinoGoldDark),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("👤", fontSize = 12.sp)
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFF5E0B11), RoundedCornerShape(6.dp))
                                            .border(1.dp, CasinoGoldDark, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = msg.text,
                                            color = Color.White,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Input Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Chat text field
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(32.dp)
                            .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                            .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = onInputChange,
                            placeholder = {
                                Text(
                                    text = "ဤနေရာမှာလူကြီးမင်း၏မေးခွန်းများကိုရေးထည့်ပေးပါ။",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            },
                            colors = TextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Purple "ဓာတ်ပုံ" (Photo) Button
                    PurplePillButton(
                        text = "ဓာတ်ပုံ",
                        onClick = onPhotoClick,
                        height = 32.dp,
                        fontSize = 12
                    )

                    // Green "ပို့ပါ" (Send) Button
                    GreenPillButton(
                        text = "ပို့ပါ",
                        onClick = onSendMessage,
                        height = 32.dp,
                        fontSize = 12
                    )
                }
            }
        }
    }
}
