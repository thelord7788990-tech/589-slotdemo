package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AdminPaymentInfo
import com.example.data.model.ChatMessage
import com.example.data.model.SettingsState
import com.example.data.model.UserProfile
import com.example.data.model.WithdrawItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class LobbyRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("slot_lobby_prefs", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(loadUserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _adminPayment = MutableStateFlow(loadAdminPayment())
    val adminPayment: StateFlow<AdminPaymentInfo> = _adminPayment.asStateFlow()

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<SettingsState> = _settings.asStateFlow()

    private val _withdrawHistory = MutableStateFlow(loadWithdrawHistory())
    val withdrawHistory: StateFlow<List<WithdrawItem>> = _withdrawHistory.asStateFlow()

    private val _chatMessages = MutableStateFlow(loadInitialChat())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private fun loadUserProfile(): UserProfile {
        return UserProfile(
            userId = prefs.getString("user_id", "79018626") ?: "79018626",
            nickname = prefs.getString("nickname", "79018626") ?: "79018626",
            accountName = prefs.getString("account_name", "Khant Hein soe") ?: "Khant Hein soe",
            phone = prefs.getString("phone", "09666769539") ?: "09666769539",
            coinBalance = prefs.getLong("coin_balance", 13L),
            syceeBalance = prefs.getLong("sycee_balance", 5L),
            vipLevel = prefs.getInt("vip_level", 1),
            boundBank = prefs.getString("bound_bank", "KBZ Pay") ?: "KBZ Pay",
            boundAccount = prefs.getString("bound_account", "09666769539") ?: "09666769539",
            boundHolder = prefs.getString("bound_holder", "Khant Hein soe") ?: "Khant Hein soe",
            isBound = prefs.getBoolean("is_bound", true)
        )
    }

    fun saveUserProfile(profile: UserProfile) {
        prefs.edit()
            .putString("user_id", profile.userId)
            .putString("nickname", profile.nickname)
            .putString("account_name", profile.accountName)
            .putString("phone", profile.phone)
            .putLong("coin_balance", profile.coinBalance)
            .putLong("sycee_balance", profile.syceeBalance)
            .putInt("vip_level", profile.vipLevel)
            .putString("bound_bank", profile.boundBank)
            .putString("bound_account", profile.boundAccount)
            .putString("bound_holder", profile.boundHolder)
            .putBoolean("is_bound", profile.isBound)
            .apply()
        _userProfile.value = profile
    }

    private fun loadAdminPayment(): AdminPaymentInfo {
        return AdminPaymentInfo(
            kbzName = prefs.getString("kbz_name", "Lae Yee Win") ?: "Lae Yee Win",
            kbzPhone = prefs.getString("kbz_phone", "09894036935") ?: "09894036935",
            waveName = prefs.getString("wave_name", "Aung Myo Thu") ?: "Aung Myo Thu",
            wavePhone = prefs.getString("wave_phone", "09782194820") ?: "09782194820"
        )
    }

    fun saveAdminPayment(info: AdminPaymentInfo) {
        prefs.edit()
            .putString("kbz_name", info.kbzName)
            .putString("kbz_phone", info.kbzPhone)
            .putString("wave_name", info.waveName)
            .putString("wave_phone", info.wavePhone)
            .apply()
        _adminPayment.value = info
    }

    private fun loadSettings(): SettingsState {
        return SettingsState(
            musicOn = prefs.getBoolean("music_on", true),
            soundOn = prefs.getBoolean("sound_on", true),
            fxOn = prefs.getBoolean("fx_on", true),
            announcementsOn = prefs.getBoolean("announcements_on", true)
        )
    }

    fun saveSettings(settings: SettingsState) {
        prefs.edit()
            .putBoolean("music_on", settings.musicOn)
            .putBoolean("sound_on", settings.soundOn)
            .putBoolean("fx_on", settings.fxOn)
            .putBoolean("announcements_on", settings.announcementsOn)
            .apply()
        _settings.value = settings
    }

    private fun loadWithdrawHistory(): List<WithdrawItem> {
        val raw = prefs.getString("withdraw_history_json", null)
        if (raw != null) {
            try {
                val list = mutableListOf<WithdrawItem>()
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(
                        WithdrawItem(
                            id = obj.getString("id"),
                            bankType = obj.optString("bankType", "ဘဏ်ကတ်"),
                            transId = obj.getString("transId"),
                            amount = obj.getLong("amount"),
                            date = obj.getString("date"),
                            status = obj.optString("status", "အောင်မြင်မှု")
                        )
                    )
                }
                return list
            } catch (_: Exception) {
                // fallback to sample
            }
        }
        // Defaults matching screenshot 12
        return listOf(
            WithdrawItem("1", "ဘဏ်ကတ်", "17921558436038972", 30000L, "2026-10-16 20:04:03", "အောင်မြင်မှု"),
            WithdrawItem("2", "ဘဏ်ကတ်", "17921540431984084", 30000L, "2026-10-16 19:34:03", "အောင်မြင်မှု"),
            WithdrawItem("3", "ဘဏ်ကတ်", "17918778674105254", 100000L, "2026-10-13 14:51:07", "အောင်မြင်မှု"),
            WithdrawItem("4", "ဘဏ်ကတ်", "17917278342334696", 20000L, "2026-10-11 21:10:34", "အောင်မြင်မှု"),
            WithdrawItem("5", "ဘဏ်ကတ်", "17916616695863176", 30000L, "2026-10-11 02:47:49", "အောင်မြင်မှု"),
            WithdrawItem("6", "ဘဏ်ကတ်", "17916614376670064", 100000L, "2026-10-11 02:43:57", "အောင်မြင်မှု")
        )
    }

    fun addWithdrawItem(item: WithdrawItem) {
        val current = _withdrawHistory.value.toMutableList()
        current.add(0, item)
        _withdrawHistory.value = current
        saveWithdrawHistory(current)
    }

    private fun saveWithdrawHistory(list: List<WithdrawItem>) {
        val arr = JSONArray()
        list.forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("bankType", item.bankType)
            obj.put("transId", item.transId)
            obj.put("amount", item.amount)
            obj.put("date", item.date)
            obj.put("status", item.status)
            arr.put(obj)
        }
        prefs.edit().putString("withdraw_history_json", arr.toString()).apply()
    }

    private fun loadInitialChat(): List<ChatMessage> {
        return listOf(
            ChatMessage(
                id = "cs-1",
                text = "၁၀၀၀၀ကျပ်မှစတင်၍ ငွေထုတ်ယူနိုင်ပါတယ်ရှင် (ဥပမာ - ၁၁၀၀၀ကျပ်ရှိလျှင် ၁၀၀၀ ချန်ပြီး ၁၀၀၀၀ကျပ် ထုတ်ယူနိုင်ပါတယ်ရှင်) အဆင်မပြေမှုများရှိပါက ၂၄နာရီဝန်ဆောင်မှုပေးသော Customer Service သို့ အချိန်မရွေး ဆက်သွယ်မေးမြန်းနိုင်ပါတယ်ရှင် အားပေးမှုကိုအထူးကျေးဇူးတင်ပါတယ်ရှင့်",
                isUser = false,
                time = "10-10 23:04:18"
            ),
            ChatMessage(
                id = "cs-2",
                text = "ငွေသွင်းမှုအောင်မြင်ပါသည်",
                isUser = true,
                time = "10-10 23:05:02"
            )
        )
    }

    fun addChatMessage(text: String, isUser: Boolean) {
        val current = _chatMessages.value.toMutableList()
        val timeStr = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        current.add(
            ChatMessage(
                id = System.currentTimeMillis().toString(),
                text = text,
                isUser = isUser,
                time = timeStr
            )
        )
        _chatMessages.value = current
    }

    fun resetToDemoDefaults() {
        prefs.edit().clear().apply()
        _userProfile.value = loadUserProfile()
        _adminPayment.value = loadAdminPayment()
        _settings.value = loadSettings()
        _withdrawHistory.value = loadWithdrawHistory()
        _chatMessages.value = loadInitialChat()
    }
}
