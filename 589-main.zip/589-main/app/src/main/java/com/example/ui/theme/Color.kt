package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Casino Red Palette
val CasinoRedDark = Color(0xFF420204)
val CasinoRedPrimary = Color(0xFF8B0007)
val CasinoRedBright = Color(0xFFD32F2F)
val CasinoRedLight = Color(0xFFFF5252)

// Casino Gold Palette
val CasinoGoldPrimary = Color(0xFFFFD700)
val CasinoGoldDark = Color(0xFFB8860B)
val CasinoGoldLight = Color(0xFFFFF176)
val CasinoGoldOrange = Color(0xFFFFA000)

// Casino Green (Deposit / Action)
val CasinoGreenPrimary = Color(0xFF00C853)
val CasinoGreenDark = Color(0xFF007E33)
val CasinoGreenLight = Color(0xFF69F0AE)

// Casino Purple
val CasinoPurplePrimary = Color(0xFF8E24AA)
val CasinoPurpleDark = Color(0xFF4A148C)
val CasinoPurpleLight = Color(0xFFBA68C8)

// Casino Teal / Cyan (Settings & Cloud Login)
val CasinoTealPrimary = Color(0xFF00838F)
val CasinoTealDark = Color(0xFF004D40)
val CasinoTealLight = Color(0xFF4DD0E1)

// Backgrounds
val CasinoLobbyBackground = Color(0xFF220305)
val CasinoPanelBackground = Color(0xFF330005)
val CasinoDialogOverlay = Color(0xCC000000)
