package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.ui.components.GreenPillButton
import com.example.ui.components.RedPillButton
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldOrange
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoRedBright
import com.example.ui.theme.CasinoRedDark
import com.example.ui.theme.CasinoRedPrimary

@Composable
fun LoginScreen(
    onQuickLogin: () -> Unit,
    onPasswordLogin: (String) -> Unit,
    onViberClick: () -> Unit,
    onExitClick: () -> Unit
) {
    var showPasswordDialog by remember { mutableStateOf(false) }
    var inputAccount by remember { mutableStateOf("79018626") }
    var inputPassword by remember { mutableStateOf("123456") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("login_screen_root")
    ) {
        // Turquoise cloud background with floating gold coins
        Image(
            painter = painterResource(id = R.drawable.login_bg_giveaway),
            contentDescription = "Giveaway Background",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Top-Left Action Icons (Exit & Viber)
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 16.dp, start = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Exit Button (Square Magenta/Pink)
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .shadow(4.dp, RoundedCornerShape(10.dp))
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFFE91E63), Color(0xFFC2185B), Color(0xFF880E4F))
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                    .border(2.dp, Color.White, RoundedCornerShape(10.dp))
                    .clickable(onClick = onExitClick)
                    .testTag("login_exit_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                    contentDescription = "Exit",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }

            // Viber Button (Square Purple with Viber label)
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .shadow(4.dp, RoundedCornerShape(10.dp))
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF9C27B0), Color(0xFF7B1FA2), Color(0xFF4A148C))
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                    .border(2.dp, Color.White, RoundedCornerShape(10.dp))
                    .clickable(onClick = onViberClick)
                    .testTag("login_viber_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = "Viber",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Viber",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Center Content (Title + Buttons)
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 3D Game Title: "GIVEAWAY GIVEAWAY"
            Box(
                modifier = Modifier.padding(bottom = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                // Shadow text
                Text(
                    text = "GIVEAWAY GIVEAWAY",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF3E0000),
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
                // Main text with yellow/orange outline
                Text(
                    text = "GIVEAWAY GIVEAWAY",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFFE53935),
                    letterSpacing = 1.sp
                )
            }

            // Subtitle banner: "FISH SHOOTING GAMES"
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(percent = 50))
                    .background(
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, CasinoGoldOrange, CasinoGoldPrimary, CasinoGoldOrange, Color.Transparent)
                        )
                    )
                    .padding(horizontal = 28.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "FISH SHOOTING GAMES",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF4E1A00),
                    letterSpacing = 2.sp
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Button 1: Password Login ("စကားဝှက်ဖြင့် Login")
            Box(
                modifier = Modifier
                    .width(280.dp)
                    .height(44.dp)
                    .shadow(6.dp, RoundedCornerShape(8.dp))
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(CasinoRedBright, CasinoRedPrimary, CasinoRedDark)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .border(1.5.dp, CasinoGoldPrimary, RoundedCornerShape(8.dp))
                    .clickable { showPasswordDialog = true }
                    .testTag("login_password_button")
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Golden Lock badge on left
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(44.dp)
                            .background(
                                brush = Brush.verticalGradient(
                                    listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                                )
                            )
                            .border(1.dp, CasinoGoldLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Lock",
                            tint = Color(0xFF4E2600),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Label text
                    Text(
                        text = "စကားဝှက်ဖြင့် Login",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Button 2: Quick Guest Entry ("အမြန်ဝင်ပါ။")
            Box(
                modifier = Modifier
                    .width(160.dp)
                    .height(38.dp)
                    .shadow(4.dp, RoundedCornerShape(percent = 50))
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF6D2428), Color(0xFF4A1417), Color(0xFF2C0A0C))
                        ),
                        shape = RoundedCornerShape(percent = 50)
                    )
                    .border(1.5.dp, CasinoGoldDark, RoundedCornerShape(percent = 50))
                    .clickable(onClick = onQuickLogin)
                    .testTag("login_quick_guest_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "အမြန်ဝင်ပါ။",
                    color = CasinoGoldLight,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Version Info Bottom-Left (v1.0.101 as in screenshot)
        Text(
            text = "v1.0.101",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 24.dp, bottom = 12.dp)
        )
    }

    // Password Login Dialog
    if (showPasswordDialog) {
        Dialog(onDismissRequest = { showPasswordDialog = false }) {
            Box(
                modifier = Modifier
                    .width(340.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF420205), Color(0xFF260103))
                        )
                    )
                    .border(2.dp, CasinoGoldPrimary, RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "စကားဝှက်ဖြင့် အကောင့်ဝင်ရန်",
                        color = CasinoGoldLight,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = inputAccount,
                        onValueChange = { inputAccount = it },
                        label = { Text("အကောင့်နံပါတ် / ဖုန်း", color = CasinoGoldDark) },
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF1E0103),
                            unfocusedContainerColor = Color(0xFF1E0103),
                            focusedIndicatorColor = CasinoGoldPrimary,
                            unfocusedIndicatorColor = CasinoGoldDark
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = inputPassword,
                        onValueChange = { inputPassword = it },
                        label = { Text("စကားဝှက်", color = CasinoGoldDark) },
                        visualTransformation = PasswordVisualTransformation(),
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF1E0103),
                            unfocusedContainerColor = Color(0xFF1E0103),
                            focusedIndicatorColor = CasinoGoldPrimary,
                            unfocusedIndicatorColor = CasinoGoldDark
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RedPillButton(
                            text = "ပယ်ဖျက်ပါ",
                            onClick = { showPasswordDialog = false }
                        )

                        GreenPillButton(
                            text = "ဝင်ရောက်ပါ",
                            onClick = {
                                showPasswordDialog = false
                                onPasswordLogin(inputPassword)
                            }
                        )
                    }
                }
            }
        }
    }
}
