package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.UserProfile
import com.example.ui.components.CopyPillButton
import com.example.ui.components.GoldPillButton
import com.example.ui.components.RedPillButton
import com.example.ui.components.TempleRoofDialog
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldOrange
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoRedBright
import com.example.ui.theme.CasinoRedDark
import com.example.ui.theme.CasinoRedPrimary

@Composable
fun ProfileDialog(
    userProfile: UserProfile,
    onClose: () -> Unit,
    onBindAccount: () -> Unit,
    onLogout: () -> Unit,
    onViewVip: () -> Unit,
    onUpdateNickname: (String) -> Unit,
    onCopy: (String, String) -> Unit
) {
    var showEditDialog by remember { mutableStateOf(false) }
    var editNicknameText by remember { mutableStateOf(userProfile.nickname) }

    TempleRoofDialog(
        title = "ကိုယ်ပိုင်သတင်းအချက်အလက်များ",
        onClose = onClose,
        modifier = Modifier.testTag("profile_dialog_root")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Main Content Area: Left Avatar + Right Info Fields
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Column: Avatar + Change Avatar Button
                Column(
                    modifier = Modifier
                        .width(130.dp)
                        .fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(105.dp)
                            .background(Color(0xFF2B0004))
                            .border(2.5.dp, CasinoGoldPrimary)
                            .padding(3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.avatar_phoenix),
                            contentDescription = "Avatar",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Change Avatar Button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp)
                            .background(
                                brush = Brush.verticalGradient(
                                    listOf(CasinoGoldOrange, CasinoGoldDark)
                                ),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(1.dp, CasinoGoldLight, RoundedCornerShape(4.dp))
                            .clickable {
                                onCopy("ခေါင်းစဉ်ဓာတ်ပုံ", "ဓာတ်ပုံရွေးချယ်မှု")
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "ခေါင်းစဉ်ဓာတ်ပုံကိုပြုပြင်ပါ",
                            color = Color(0xFF2E0900),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Right Column: User Balance and Account Details
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    // Balance Row 1: Gold Coin
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp)
                            .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                            .border(1.dp, Color(0xFF5A1418), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(CasinoGoldPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🪙", fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = userProfile.coinBalance.toString(),
                            color = CasinoGoldLight,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Balance Row 2: Sycee Ingot
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp)
                            .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                            .border(1.dp, Color(0xFF5A1418), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🧈", fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = userProfile.syceeBalance.toString(),
                            color = CasinoGoldLight,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Row 3: Nickname + Edit Pencil
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(30.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "အမည်",
                            color = CasinoGoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.width(65.dp)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(28.dp)
                                .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                                .border(1.dp, Color(0xFF5A1418), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = userProfile.nickname,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(CasinoGoldOrange, RoundedCornerShape(4.dp))
                                .clickable { showEditDialog = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Nickname",
                                tint = Color(0xFF3E1E00),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Row 4: ID + Copy Button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(30.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "ID",
                            color = CasinoGoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.width(65.dp)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(28.dp)
                                .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                                .border(1.dp, Color(0xFF5A1418), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = userProfile.userId,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        CopyPillButton(
                            onClick = { onCopy(userProfile.userId, "ID") }
                        )
                    }

                    // Row 5: Account Name + Copy Button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(30.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "အကောင့်နာမည်",
                            color = CasinoGoldLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.width(65.dp)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(28.dp)
                                .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                                .border(1.dp, Color(0xFF5A1418), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = userProfile.accountName,
                                color = Color.White,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        CopyPillButton(
                            onClick = { onCopy(userProfile.accountName, "အကောင့်နာမည်") }
                        )
                    }
                }
            }

            // VIP Section Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .background(Color(0xFF2A0205))
                    .border(1.dp, Color(0xFF580C12))
                    .clickable(onClick = onViewVip)
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // VIP Badge
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(
                                brush = Brush.radialGradient(
                                    listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                                ),
                                shape = CircleShape
                            )
                            .border(1.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "1",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF4A1E00)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "VIP အကျိုးကျေးဇူးများ",
                        color = CasinoGoldLight,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // View VIP Privileges Button
                Box(
                    modifier = Modifier
                        .height(28.dp)
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(CasinoGoldOrange, CasinoGoldDark)
                            ),
                            shape = RoundedCornerShape(percent = 50)
                        )
                        .border(1.dp, Color.White, RoundedCornerShape(percent = 50))
                        .clickable(onClick = onViewVip)
                        .padding(horizontal = 12.dp, vertical = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "VIP အခွင့်အရေးကိုကြည့်ပါ",
                        color = Color(0xFF2B0A00),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Bottom Action Pill Buttons (Bind Account & Logout)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GoldPillButton(
                    text = "အကောင့်ချိတ်ပါ",
                    onClick = onBindAccount,
                    height = 32.dp,
                    fontSize = 13
                )

                RedPillButton(
                    text = "ဂိမ်းကနေထွက်လိုက်ပါ",
                    onClick = onLogout,
                    height = 32.dp,
                    fontSize = 13
                )
            }
        }
    }

    // Edit Nickname Dialog
    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = {
                Text(
                    text = "အမည်ပြောင်းလဲပါ",
                    color = CasinoGoldLight,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                OutlinedTextField(
                    value = editNicknameText,
                    onValueChange = { editNicknameText = it },
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF2B0104),
                        unfocusedContainerColor = Color(0xFF2B0104),
                        focusedIndicatorColor = CasinoGoldPrimary,
                        unfocusedIndicatorColor = CasinoGoldDark
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (editNicknameText.isNotBlank()) {
                            onUpdateNickname(editNicknameText)
                        }
                        showEditDialog = false
                    }
                ) {
                    Text("သေချာပါပြီ", color = CasinoGoldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("ပယ်ဖျက်ပါ", color = Color.White)
                }
            },
            containerColor = Color(0xFF3E0206)
        )
    }
}
