package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.model.AdminPaymentInfo
import com.example.data.model.AppScreen
import com.example.data.model.GameCard
import com.example.data.model.LobbyDialogType
import com.example.data.model.SettingsState
import com.example.data.model.UserProfile
import com.example.data.model.WithdrawItem
import com.example.data.repository.LobbyRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LobbyViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = LobbyRepository(application)

    val userProfile: StateFlow<UserProfile> = repository.userProfile
    val adminPayment: StateFlow<AdminPaymentInfo> = repository.adminPayment
    val settings: StateFlow<SettingsState> = repository.settings
    val withdrawHistory: StateFlow<List<WithdrawItem>> = repository.withdrawHistory
    val chatMessages = repository.chatMessages

    private val _currentScreen = MutableStateFlow(AppScreen.SPLASH)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _activeDialog = MutableStateFlow(LobbyDialogType.NONE)
    val activeDialog: StateFlow<LobbyDialogType> = _activeDialog.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Deposit State
    private val _selectedDepositMethod = MutableStateFlow("KBZ Pay")
    val selectedDepositMethod: StateFlow<String> = _selectedDepositMethod.asStateFlow()

    private val _depositAmount = MutableStateFlow(10000L)
    val depositAmount: StateFlow<Long> = _depositAmount.asStateFlow()

    private val _depositReceiptCode = MutableStateFlow("")
    val depositReceiptCode: StateFlow<String> = _depositReceiptCode.asStateFlow()

    private val _depositPayerName = MutableStateFlow("")
    val depositPayerName: StateFlow<String> = _depositPayerName.asStateFlow()

    // Withdraw State
    private val _withdrawAmount = MutableStateFlow(0L)
    val withdrawAmount: StateFlow<Long> = _withdrawAmount.asStateFlow()

    // Bank binding temp state
    private val _bindBankName = MutableStateFlow("KBZ Pay")
    val bindBankName: StateFlow<String> = _bindBankName.asStateFlow()

    private val _bindAccountNumber = MutableStateFlow("09666769539")
    val bindAccountNumber: StateFlow<String> = _bindAccountNumber.asStateFlow()

    private val _bindAccountHolder = MutableStateFlow("Khant Hein soe")
    val bindAccountHolder: StateFlow<String> = _bindAccountHolder.asStateFlow()

    // Game state
    private val _selectedGame = MutableStateFlow<GameCard?>(null)
    val selectedGame: StateFlow<GameCard?> = _selectedGame.asStateFlow()

    // Customer Service State
    private val _csInputText = MutableStateFlow("")
    val csInputText: StateFlow<String> = _csInputText.asStateFlow()

    private val _csActiveTab = MutableStateFlow(1) // 0: FAQ, 1: Online CS, 2: Feedback
    val csActiveTab: StateFlow<Int> = _csActiveTab.asStateFlow()

    // Games catalog
    val gameCards: List<GameCard> = listOf(
        GameCard(
            id = "fish_hunter",
            title = "ဂိမ်းအမဲလိုက်",
            subtitle = "FISH SHOOTING",
            imageRes = R.drawable.game_fish_croc,
            isFishGame = true
        ),
        GameCard(
            id = "african_buffalo",
            title = "AFRICAN BUFFALO",
            subtitle = "BUFFALO RAGE",
            imageRes = R.drawable.game_buffalo
        ),
        GameCard(
            id = "fire_link",
            title = "ULTIMATE FIRE LINK",
            subtitle = "JACKPOT TREE",
            jackpot1 = 15180155L,
            jackpot2 = 7334175L,
            imageRes = R.drawable.game_firelink
        ),
        GameCard(
            id = "grand_dragons",
            title = "GRAND DRAGONS",
            subtitle = "IMPERIAL DRAGON",
            jackpot1 = 8888888L,
            imageRes = R.drawable.game_dragon
        ),
        GameCard(
            id = "luxury_buffalo",
            title = "LUXURY LINE BUFFALO",
            subtitle = "CASH EXPRESS",
            jackpot1 = 15295763L,
            jackpot2 = 5725311L,
            imageRes = R.drawable.game_buffalo
        ),
        GameCard(
            id = "pirate_fortune",
            title = "PIRATE FORTUNE",
            subtitle = "SEVEN SEAS",
            jackpot1 = 15299042L,
            jackpot2 = 5557490L,
            imageRes = R.drawable.game_pirate
        )
    )

    init {
        // Auto transition splash screen
        viewModelScope.launch {
            delay(1600)
            if (_currentScreen.value == AppScreen.SPLASH) {
                _currentScreen.value = AppScreen.LOGIN
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun openDialog(dialogType: LobbyDialogType) {
        _activeDialog.value = dialogType
    }

    fun closeDialog() {
        _activeDialog.value = LobbyDialogType.NONE
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
        viewModelScope.launch {
            delay(2500)
            if (_toastMessage.value == msg) {
                _toastMessage.value = null
            }
        }
    }

    // Login Actions
    fun loginQuickGuest() {
        _currentScreen.value = AppScreen.LOBBY
        showToast("ဧည့်သည်အဖြစ် အောင်မြင်စွာဝင်ရောက်ခဲ့သည်")
    }

    fun loginWithPassword(password: String) {
        _currentScreen.value = AppScreen.LOBBY
        showToast("အကောင့်ဝင်ရောက်မှု အောင်မြင်ပါသည်")
    }

    // Deposit Flow
    fun setDepositMethod(method: String) {
        _selectedDepositMethod.value = method
    }

    fun setDepositAmount(amount: Long) {
        _depositAmount.value = amount
    }

    fun proceedToDepositTransfer() {
        _activeDialog.value = LobbyDialogType.DEPOSIT_TRANSFER
    }

    fun setDepositReceiptCode(code: String) {
        _depositReceiptCode.value = code
    }

    fun setDepositPayerName(name: String) {
        _depositPayerName.value = name
    }

    fun confirmDepositTransfer() {
        // Instant alert popup as seen in screenshot 11
        _activeDialog.value = LobbyDialogType.INSTANT_ALERT
        // Increment demo balance slightly after delay
        viewModelScope.launch {
            val current = userProfile.value
            val addedCoins = _depositAmount.value / 1000
            repository.saveUserProfile(current.copy(coinBalance = current.coinBalance + addedCoins))
            repository.addChatMessage("ငွေသွင်းမှုပမာဏ ${_depositAmount.value} ကျပ် (Demo) တောင်းဆိုချက် လက်ခံရရှိပါသည်", false)
        }
    }

    // Withdraw Flow
    fun setWithdrawAmount(amount: Long) {
        _withdrawAmount.value = amount
    }

    fun setMaxWithdrawAmount() {
        val currentCoins = userProfile.value.coinBalance
        _withdrawAmount.value = currentCoins
    }

    fun confirmWithdraw() {
        val amount = _withdrawAmount.value
        val profile = userProfile.value
        if (amount <= 0) {
            showToast("ငွေထုတ်ပမာဏကို ရိုက်ထည့်ပါ")
            return
        }
        if (amount > profile.coinBalance) {
            showToast("လက်ကျန်ငွေ မလုံလောက်ပါ")
            return
        }
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val transId = "179" + (10000000000000L..99999999999999L).random()
        repository.addWithdrawItem(
            WithdrawItem(
                id = System.currentTimeMillis().toString(),
                bankType = profile.boundBank,
                transId = transId,
                amount = amount * 1000L,
                date = dateStr,
                status = "အောင်မြင်မှု"
            )
        )
        repository.saveUserProfile(profile.copy(coinBalance = profile.coinBalance - amount))
        _withdrawAmount.value = 0
        showToast("ငွေထုတ်ယူခြင်း အောင်မြင်ပါသည် (Demo)")
        _activeDialog.value = LobbyDialogType.TRANSACTION_HISTORY
    }

    // Binding Bank Flow
    fun setBindBankName(bank: String) {
        _bindBankName.value = bank
    }

    fun setBindAccountNumber(num: String) {
        _bindAccountNumber.value = num
    }

    fun setBindAccountHolder(holder: String) {
        _bindAccountHolder.value = holder
    }

    fun confirmBankBinding() {
        val current = userProfile.value
        repository.saveUserProfile(
            current.copy(
                boundBank = _bindBankName.value,
                boundAccount = _bindAccountNumber.value,
                boundHolder = _bindAccountHolder.value,
                isBound = true
            )
        )
        showToast("ဘဏ်အကောင့်ချည်နှောင်ခြင်း ပြီးပါပြီ")
        _activeDialog.value = LobbyDialogType.NONE
    }

    // Profile Actions
    fun updateNickname(newName: String) {
        val current = userProfile.value
        repository.saveUserProfile(current.copy(nickname = newName))
        showToast("အမည်ပြောင်းလဲခြင်း အောင်မြင်ပါသည်")
    }

    // Settings
    fun toggleMusic() {
        val current = settings.value
        repository.saveSettings(current.copy(musicOn = !current.musicOn))
    }

    fun toggleSound() {
        val current = settings.value
        repository.saveSettings(current.copy(soundOn = !current.soundOn))
    }

    fun toggleFx() {
        val current = settings.value
        repository.saveSettings(current.copy(fxOn = !current.fxOn))
    }

    fun toggleAnnouncements() {
        val current = settings.value
        repository.saveSettings(current.copy(announcementsOn = !current.announcementsOn))
    }

    // Admin Payment Config
    fun updateAdminPayment(kbzName: String, kbzPhone: String, waveName: String, wavePhone: String) {
        repository.saveAdminPayment(
            AdminPaymentInfo(
                kbzName = kbzName,
                kbzPhone = kbzPhone,
                waveName = waveName,
                wavePhone = wavePhone
            )
        )
        showToast("ငွေပေးချေမှု Demo အချက်အလက်များ သိမ်းဆည်းပြီးပါပြီ")
    }

    // Customer Service Chat
    fun setCsInputText(text: String) {
        _csInputText.value = text
    }

    fun setCsActiveTab(tab: Int) {
        _csActiveTab.value = tab
    }

    fun sendCsMessage() {
        val text = _csInputText.value.trim()
        if (text.isEmpty()) return
        repository.addChatMessage(text, true)
        _csInputText.value = ""
        viewModelScope.launch {
            delay(1200)
            repository.addChatMessage("လူကြီးမင်း၏ မေးမြန်းချက်ကို လက်ခံရရှိပါသည်၊ ခေတ္တစောင့်ဆိုင်းပေးပါရှင်။ (Demo)", false)
        }
    }

    // Game Clicked
    fun onGameCardClicked(game: GameCard) {
        _selectedGame.value = game
        _activeDialog.value = LobbyDialogType.GAME_DEMO
    }

    // Copy to clipboard demo
    fun copyToClipboard(text: String, label: String) {
        showToast("$label ကူးယူပြီးပါပြီ: $text")
    }

    fun resetDemoData() {
        repository.resetToDemoDefaults()
        showToast("Demo အချက်အလက်များကို မူလအတိုင်း ပြန်လည်သတ်မှတ်ပြီးပါပြီ")
    }
}
