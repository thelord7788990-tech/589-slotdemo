package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldOrange
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoGreenDark
import com.example.ui.theme.CasinoGreenLight
import com.example.ui.theme.CasinoGreenPrimary
import com.example.ui.theme.CasinoRedBright
import com.example.ui.theme.CasinoRedDark
import com.example.ui.theme.CasinoRedPrimary

/**
 * Asian Temple Roof Dialog Container matching reference screenshots
 */
@Composable
fun TempleRoofDialog(
    title: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    bottomActionText: String? = null,
    onBottomAction: (() -> Unit)? = null,
    isGreenRoof: Boolean = true,
    content: @Composable () -> Unit
) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xB3000000))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClose
                ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = modifier
                    .fillMaxWidth(0.92f)
                    .fillMaxHeight(0.92f)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { /* consume click */ }
                    )
            ) {
                // Main Dialog Body
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 28.dp, bottom = if (bottomActionText != null) 20.dp else 0.dp)
                ) {
                    // Roof eaves
                    TempleRoofEaves(
                        title = title,
                        isGreen = isGreenRoof
                    )

                    // Inner Content Frame
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(
                                brush = Brush.verticalGradient(
                                    listOf(
                                        Color(0xFF5A0208),
                                        Color(0xFF380104),
                                        Color(0xFF260103)
                                    )
                                )
                            )
                            .border(
                                border = BorderStroke(
                                    2.dp,
                                    Brush.verticalGradient(
                                        listOf(CasinoGoldPrimary, CasinoGoldDark, CasinoGoldPrimary)
                                    )
                                )
                            )
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        content()
                    }

                    // Bottom Red Step Base
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(16.dp)
                            .background(
                                brush = Brush.verticalGradient(
                                    listOf(CasinoRedPrimary, CasinoRedDark, Color(0xFF1F0002))
                                )
                            )
                            .border(1.dp, CasinoGoldDark)
                    )
                }

                // Close Button Top Right (Red circle with gold border & yellow X)
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = (-16).dp, y = 6.dp)
                        .size(44.dp)
                        .shadow(6.dp, CircleShape)
                        .background(
                            brush = Brush.radialGradient(
                                listOf(CasinoRedBright, CasinoRedPrimary, CasinoRedDark)
                            ),
                            shape = CircleShape
                        )
                        .border(2.5.dp, CasinoGoldPrimary, CircleShape)
                        .clickable(onClick = onClose)
                        .testTag("dialog_close_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = CasinoGoldLight,
                        modifier = Modifier.size(26.dp)
                    )
                }

                // Optional Bottom Floating Action Button (Green Pill e.g. "သေချာပါတယ်")
                if (bottomActionText != null && onBottomAction != null) {
                    GreenPillButton(
                        text = bottomActionText,
                        onClick = onBottomAction,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .offset(y = 4.dp)
                    )
                }
            }
        }
    }
}

/**
 * Asian temple roof eaves with gold calligraphic title
 */
@Composable
fun TempleRoofEaves(
    title: String,
    isGreen: Boolean = true
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Eaves curve
            val path = Path().apply {
                moveTo(0f, height)
                // Left curve tip pointing upward
                cubicTo(width * 0.15f, height * 0.65f, width * 0.3f, 4f, width * 0.5f, 0f)
                cubicTo(width * 0.7f, 4f, width * 0.85f, height * 0.65f, width, height)
                close()
            }

            // Green glazed tiles or Cyan roof
            val roofGradient = Brush.verticalGradient(
                if (isGreen) {
                    listOf(Color(0xFF2ECC71), Color(0xFF00C853), Color(0xFF007E33), Color(0xFF004D20))
                } else {
                    listOf(Color(0xFF4DD0E1), Color(0xFF00ACC1), Color(0xFF00838F), Color(0xFF004D40))
                }
            )
            drawPath(path, roofGradient)

            // Golden ridge trim
            val goldTrimPath = Path().apply {
                moveTo(0f, height)
                cubicTo(width * 0.15f, height * 0.65f, width * 0.3f, 4f, width * 0.5f, 0f)
                cubicTo(width * 0.7f, 4f, width * 0.85f, height * 0.65f, width, height)
                lineTo(width, height - 4f)
                cubicTo(width * 0.85f, height * 0.65f - 4f, width * 0.7f, 0f, width * 0.5f, -4f)
                cubicTo(width * 0.3f, 0f, width * 0.15f, height * 0.65f - 4f, 0f, height - 4f)
                close()
            }
            drawPath(goldTrimPath, Brush.horizontalGradient(listOf(CasinoGoldPrimary, CasinoGoldLight, CasinoGoldPrimary)))
        }

        // Title text in Burmese calligraphy style with gold gradient
        Text(
            text = title,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = CasinoGoldLight,
            modifier = Modifier.padding(horizontal = 48.dp),
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Green Pill Action Button (like "သေချာပါတယ်", "လုံလွယ်", "ဖြည့်ပါ")
 */
@Composable
fun GreenPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 38.dp,
    fontSize: Int = 15
) {
    Box(
        modifier = modifier
            .height(height)
            .shadow(6.dp, RoundedCornerShape(percent = 50))
            .background(
                brush = Brush.verticalGradient(
                    listOf(CasinoGreenLight, CasinoGreenPrimary, CasinoGreenDark)
                ),
                shape = RoundedCornerShape(percent = 50)
            )
            .border(
                1.5.dp,
                Brush.verticalGradient(listOf(Color.White, CasinoGoldLight, CasinoGreenDark)),
                RoundedCornerShape(percent = 50)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 26.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = fontSize.sp,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Yellow / Gold Pill Button (like "အကောင့်ချိတ်ပါ", "ဘဏ်ကတ်")
 */
@Composable
fun GoldPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 34.dp,
    fontSize: Int = 14
) {
    Box(
        modifier = modifier
            .height(height)
            .shadow(4.dp, RoundedCornerShape(percent = 50))
            .background(
                brush = Brush.verticalGradient(
                    listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                ),
                shape = RoundedCornerShape(percent = 50)
            )
            .border(1.5.dp, Color.White, RoundedCornerShape(percent = 50))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color(0xFF3E2723),
            fontWeight = FontWeight.ExtraBold,
            fontSize = fontSize.sp,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Red Pill Button (for Cancel / Exit)
 */
@Composable
fun RedPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 34.dp,
    fontSize: Int = 14
) {
    Box(
        modifier = modifier
            .height(height)
            .shadow(4.dp, RoundedCornerShape(percent = 50))
            .background(
                brush = Brush.verticalGradient(
                    listOf(CasinoRedBright, CasinoRedPrimary, CasinoRedDark)
                ),
                shape = RoundedCornerShape(percent = 50)
            )
            .border(1.5.dp, CasinoGoldPrimary, RoundedCornerShape(percent = 50))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = fontSize.sp,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Small Copy Pill Button "ကူးယူပါ"
 */
@Composable
fun CopyPillButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    text: String = "ကူးယူပါ"
) {
    Box(
        modifier = modifier
            .height(28.dp)
            .background(
                brush = Brush.verticalGradient(
                    listOf(CasinoRedBright, CasinoRedDark)
                ),
                shape = RoundedCornerShape(4.dp)
            )
            .border(1.dp, CasinoGoldPrimary, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = CasinoGoldLight,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

/**
 * Purple Pill Button (like "ငွေထုတ်မှတ်တမ်း", "ဘဏ်ကတ်ချည်နှောင်ခြင်း", "အကြီးဆုံး")
 */
@Composable
fun PurplePillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 28.dp,
    fontSize: Int = 11
) {
    Box(
        modifier = modifier
            .height(height)
            .background(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFFAB47BC), Color(0xFF7B1FA2), Color(0xFF4A148C))
                ),
                shape = RoundedCornerShape(4.dp)
            )
            .border(1.dp, CasinoGoldLight, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = fontSize.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

/**
 * Gold Coin Toggle Switch (As shown in Settings screenshot 5b)
 */
@Composable
fun CoinToggleSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .width(82.dp)
            .height(30.dp)
            .clip(RoundedCornerShape(percent = 50))
            .background(
                brush = Brush.verticalGradient(
                    if (checked) {
                        listOf(Color(0xFF26C6DA), Color(0xFF00ACC1), Color(0xFF00838F))
                    } else {
                        listOf(Color(0xFF78909C), Color(0xFF546E7A), Color(0xFF37474F))
                    }
                )
            )
            .border(1.5.dp, Color.White, RoundedCornerShape(percent = 50))
            .clickable { onCheckedChange(!checked) }
            .padding(2.dp)
    ) {
        // Label inside track (ON / OFF)
        Text(
            text = if (checked) "ON" else "OFF",
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 13.sp,
            modifier = Modifier
                .align(if (checked) Alignment.CenterStart else Alignment.CenterEnd)
                .padding(horizontal = 8.dp)
        )

        // Golden coin knob
        Box(
            modifier = Modifier
                .size(26.dp)
                .align(if (checked) Alignment.CenterEnd else Alignment.CenterStart)
                .shadow(2.dp, CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                    ),
                    shape = CircleShape
                )
                .border(1.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(12.dp)) {
                // Chinese coin square center hole
                drawRect(
                    color = CasinoGoldDark,
                    topLeft = Offset(size.width * 0.25f, size.height * 0.25f),
                    size = androidx.compose.ui.geometry.Size(size.width * 0.5f, size.height * 0.5f)
                )
            }
        }
    }
}

/**
 * Marquee Ticker at the top of the lobby
 */
@Composable
fun MarqueeBanner(
    text: String,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "marquee")
    val offsetProgress by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = -1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "marquee_offset"
    )

    BoxWithConstraints(
        modifier = modifier
            .height(26.dp)
            .clip(RoundedCornerShape(percent = 50))
            .background(Color(0x88000000))
            .border(1.dp, CasinoRedBright, RoundedCornerShape(percent = 50))
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        val totalWidth = maxWidth.value
        Text(
            text = text,
            color = CasinoGoldLight,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            modifier = Modifier.offset {
                IntOffset(
                    x = (totalWidth * offsetProgress * 2).toInt(),
                    y = 0
                )
            }
        )
    }
}
