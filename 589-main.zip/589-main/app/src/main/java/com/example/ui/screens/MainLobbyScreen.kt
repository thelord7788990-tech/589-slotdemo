package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.GameCard
import com.example.data.model.UserProfile
import com.example.ui.components.MarqueeBanner
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldOrange
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoGreenDark
import com.example.ui.theme.CasinoGreenLight
import com.example.ui.theme.CasinoGreenPrimary
import com.example.ui.theme.CasinoRedBright
import com.example.ui.theme.CasinoRedDark
import com.example.ui.theme.CasinoRedPrimary

@Composable
fun MainLobbyScreen(
    userProfile: UserProfile,
    gameCards: List<GameCard>,
    onProfileClick: () -> Unit,
    onVipClick: () -> Unit,
    onDepositClick: () -> Unit,
    onWithdrawClick: () -> Unit,
    onBindAccountClick: () -> Unit,
    onVaultClick: () -> Unit,
    onCsClick: () -> Unit,
    onActivityClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOfficialWebsiteClick: () -> Unit,
    onGameClick: (GameCard) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_lobby_root")
    ) {
        // Deep red imperial casino wallpaper background
        Image(
            painter = painterResource(id = R.drawable.lobby_bg_pattern),
            contentDescription = "Casino Background",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Main Vertical Layout (Top Bar, Center Games, Bottom Bar)
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // ----------------------------------------
            // TOP BAR SECTION
            // ----------------------------------------
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(Color(0xFF380004), Color(0xFF1E0002))
                            )
                        )
                        .border(1.dp, CasinoRedPrimary)
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Left Group: Avatar + VIP Badge + Coin Balance + Deposit Button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Phoenix Avatar Frame
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .border(1.5.dp, CasinoGoldPrimary, RoundedCornerShape(4.dp))
                                .clickable(onClick = onProfileClick)
                                .testTag("lobby_avatar_button")
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.avatar_phoenix),
                                contentDescription = "Avatar",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // VIP 1 Badge
                        Box(
                            modifier = Modifier
                                .height(26.dp)
                                .clip(RoundedCornerShape(percent = 50))
                                .background(
                                    brush = Brush.horizontalGradient(
                                        listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                                    )
                                )
                                .border(1.dp, Color.White, RoundedCornerShape(percent = 50))
                                .clickable(onClick = onVipClick)
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "VIP ${userProfile.vipLevel}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF3B1E00)
                            )
                        }

                        // Coin Balance Capsule with Green "ဖြည့်ပါ" Button
                        Row(
                            modifier = Modifier
                                .height(30.dp)
                                .clip(RoundedCornerShape(percent = 50))
                                .background(Color(0xFF2B0104))
                                .border(1.dp, CasinoGoldDark, RoundedCornerShape(percent = 50))
                                .padding(start = 6.dp, end = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🪙", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = userProfile.coinBalance.toString(),
                                color = CasinoGoldLight,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            // Green "ဖြည့်ပါ" (Deposit)
                            Box(
                                modifier = Modifier
                                    .height(24.dp)
                                    .clip(RoundedCornerShape(percent = 50))
                                    .background(
                                        brush = Brush.verticalGradient(
                                            listOf(CasinoGreenLight, CasinoGreenPrimary, CasinoGreenDark)
                                        )
                                    )
                                    .border(1.dp, Color.White, RoundedCornerShape(percent = 50))
                                    .clickable(onClick = onDepositClick)
                                    .padding(horizontal = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "ဖြည့်ပါ",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Center Group: Official Website Button + Sycee Balance
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Purple Official Website Button
                        Box(
                            modifier = Modifier
                                .height(28.dp)
                                .clip(RoundedCornerShape(percent = 50))
                                .background(
                                    brush = Brush.horizontalGradient(
                                        listOf(Color(0xFF8E24AA), Color(0xFF5E35B1))
                                    )
                                )
                                .border(1.dp, CasinoGoldLight, RoundedCornerShape(percent = 50))
                                .clickable(onClick = onOfficialWebsiteClick)
                                .padding(horizontal = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "တရားဝင်ဝက်ဆိုက်ကိုကူးပါ",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Sycee Ingot Balance Capsule
                        Row(
                            modifier = Modifier
                                .height(30.dp)
                                .clip(RoundedCornerShape(percent = 50))
                                .background(Color(0xFF2B0104))
                                .border(1.dp, CasinoGoldDark, RoundedCornerShape(percent = 50))
                                .clickable(onClick = onVaultClick)
                                .padding(horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🧈", fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = userProfile.syceeBalance.toString(),
                                color = CasinoGoldLight,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Right Group: Settings Gear Button
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                brush = Brush.radialGradient(
                                    listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                                )
                            )
                            .border(1.5.dp, Color.White, CircleShape)
                            .clickable(onClick = onSettingsClick)
                            .testTag("lobby_settings_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color(0xFF381400),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Marquee Ticker: https://589slot.co
                MarqueeBanner(
                    text = "https://589slot.co ★ 589 SLOT ဂိမ်းမှ ကြိုဆိုပါသည် ★ ၂၄ နာရီ ငွေသွင်း/ငွေထုတ် လျင်မြန်စွာ ဆောင်ရွက်ပေးနေပါသည် ★ တရားဝင် လင့်ခ် https://589slot.co",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 2.dp)
                )
            }

            // ----------------------------------------
            // CENTER: HORIZONTAL GAME CARDS SCROLL
            // ----------------------------------------
            val scrollState = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .horizontalScroll(scrollState)
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                gameCards.forEach { game ->
                    GameCardItem(
                        game = game,
                        onClick = { onGameClick(game) }
                    )
                }
            }

            // ----------------------------------------
            // BOTTOM BAR SECTION
            // ----------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF2E0104), Color(0xFF140002))
                        )
                    )
                    .border(1.dp, CasinoRedPrimary)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left Group: 24hr Customer Service + Bank Vault Safe
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 24hr CS Envelope
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(onClick = onCsClick)
                            .testTag("lobby_bottom_cs_button")
                    ) {
                        Box(contentAlignment = Alignment.TopEnd) {
                            Text("✉️", fontSize = 20.sp)
                            // Red notification dot
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(Color.Red)
                            )
                        }
                        Text(
                            text = "၂၄ နာရီ ဝန်ဆောင်မှု",
                            color = CasinoGoldLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Bank Vault / Safe (ဘဏ်သေတ္တာ)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(onClick = onVaultClick)
                            .testTag("lobby_bottom_vault_button")
                    ) {
                        Text("🎁", fontSize = 20.sp)
                        Text(
                            text = "ဘဏ်သေတ္တာ",
                            color = CasinoGoldLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Center Action Buttons: Coins display, Withdraw, Bind Account, VIP, Activity
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Coin pill
                    Box(
                        modifier = Modifier
                            .height(28.dp)
                            .background(Color(0xFF260103), RoundedCornerShape(percent = 50))
                            .border(1.dp, CasinoGoldDark, RoundedCornerShape(percent = 50))
                            .padding(horizontal = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "🪙 ${userProfile.coinBalance}",
                            color = CasinoGoldLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // 1. "ထုတ်ယူခြင်း" (Withdraw)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(onClick = onWithdrawClick)
                            .testTag("lobby_bottom_withdraw_button")
                    ) {
                        Text("💰", fontSize = 18.sp)
                        Text(
                            text = "ထုတ်ယူခြင်း",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // 2. "အကောင့်ချည်နှောင်သည်" (Bind Account)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(onClick = onBindAccountClick)
                            .testTag("lobby_bottom_bind_button")
                    ) {
                        Text("🪪", fontSize = 18.sp)
                        Text(
                            text = "အကောင့်ချည်နှောင်သည်",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // 3. "VIP အကျိုးခံစားခွင့်" (VIP Benefits)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(onClick = onVipClick)
                            .testTag("lobby_bottom_vip_button")
                    ) {
                        Text("👑", fontSize = 18.sp)
                        Text(
                            text = "VIP အကျိုးခံစားခွင့်",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // 4. "လှုပ်ရှားမှုစင်တာ" (Activity Center)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(onClick = onActivityClick)
                            .testTag("lobby_bottom_activity_button")
                    ) {
                        Text("🏮", fontSize = 18.sp)
                        Text(
                            text = "လှုပ်ရှားမှုစင်တာ",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Right: Big Glowing Circular "ဖြည့်ပါ" (Deposit) Button
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .shadow(8.dp, CircleShape)
                        .background(
                            brush = Brush.radialGradient(
                                listOf(CasinoRedBright, CasinoRedPrimary, CasinoRedDark)
                            ),
                            shape = CircleShape
                        )
                        .border(2.5.dp, CasinoGoldPrimary, CircleShape)
                        .clickable(onClick = onDepositClick)
                        .testTag("lobby_deposit_circle_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "ဖြည့်ပါ",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

/**
 * Individual Slot Game Card with Chinese scroll frame / jackpot tickers
 */
@Composable
fun GameCardItem(
    game: GameCard,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .width(135.dp)
            .fillMaxHeight(0.94f)
            .clickable(onClick = onClick)
            .testTag("game_card_${game.id}")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Jackpot banner if present
            if (game.jackpot1 > 0) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(Color(0xFF003859), Color(0xFF001F33))
                            ),
                            shape = RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)
                        )
                        .border(1.dp, CasinoGoldPrimary, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = game.subtitle.ifEmpty { "JACKPOT" },
                            color = CasinoGoldLight,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "${game.jackpot1}",
                            color = Color(0xFFFFEB3B),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            // Game Poster Frame with gold scroll edge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(
                        if (game.isFishGame) RoundedCornerShape(8.dp) else RoundedCornerShape(4.dp)
                    )
                    .border(
                        if (game.isFishGame) 3.dp else 2.dp,
                        if (game.isFishGame) CasinoGoldPrimary else Color(0xFF7E57C2),
                        if (game.isFishGame) RoundedCornerShape(8.dp) else RoundedCornerShape(4.dp)
                    )
            ) {
                Image(
                    painter = painterResource(id = game.imageRes),
                    contentDescription = game.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Bottom title banner overlay on card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xCC000000), Color(0xFF1B0002))
                            )
                        )
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = game.title,
                        color = CasinoGoldLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
