# 589 Slot - Native Android Slot Game Lobby UI (Offline Demo)

A complete native Android application built with Kotlin and Jetpack Compose that recreates the casino slot game lobby UI based on the reference screenshots.

## Features & UI Screens

1. **Splash Screen**:
   - Imperial red background with golden dragon casino emblem.
   - Animated loading bar with percentage feedback.

2. **Login Screen (Screenshot 13)**:
   - "GIVEAWAY GIVEAWAY - FISH SHOOTING GAMES" banner with oriental teal clouds and floating gold coins.
   - Quick guest entry button: `အမြန်ဝင်ပါ။` (immediately enters the Lobby).
   - Password login button: `စကားဝှက်ဖြင့် Login` with credentials popup.
   - Top-left Viber contact and Exit application buttons.
   - Version label `v1.0.101`.

3. **Main Lobby (Screenshot 14)**:
   - **Top Navigation Bar**:
     - User Avatar (Phoenix) & `VIP 1` badge (clickable).
     - Gold coin balance capsule with quick green `ဖြည့်ပါ` (Deposit) button.
     - Purple `တရားဝင်ဝက်ဆိုက်ကိုကူးပါ` (Copy Official Website) button (`https://589slot.co`).
     - Sycee ingot balance capsule (clickable to open Bank Vault).
     - Settings gear icon.
     - Animated scrolling marquee ticker banner.
   - **Center Game Carousel (Horizontal Scroll)**:
     - 1. **Crocodile Fish Hunter** (`ဂိမ်းအမဲလိုက်` with gold carved frame).
     - 2. **African Buffalo** (`AFRICAN BUFFALO` with scroll mount banner).
     - 3. **Ultimate Fire Link China Street** (`ULTIMATE FIRE LINK` with Jackpot Tree tickers).
     - 4. **Grand Dragons** (`GRAND DRAGONS` with imperial Chinese dragon).
     - 5. **Luxury Line Buffalo** (`CASH EXPRESS LUXURY LINE BUFFALO` with tickers).
     - 6. **Pirate Fortune** (`PIRATE FORTUNE` with female pirate cutlass artwork).
     - Tapping any game card opens the Game Demo information & free-play spin popup.
   - **Bottom Navigation Bar**:
     - 24-hour Customer Service envelope with notification dot (`၂၄ နာရီ ဝန်ဆောင်မှု`).
     - Bank Vault / Safe (`ဘဏ်သေတ္တာ`).
     - Live coin balance capsule.
     - `ထုတ်ယူခြင်း` (Withdraw).
     - `အကောင့်ချည်နှောင်သည်` (Bind Account).
     - `VIP အကျိုးခံစားခွင့်` (VIP Benefits).
     - `လှုပ်ရှားမှုစင်တာ` (Activity / Event Center).
     - Giant glowing red circular `ဖြည့်ပါ` (Deposit) button.

4. **Dialogs & Sub-screens**:
   - **Profile Dialog (Screenshot 4)**:
     - Avatar with `ခေါင်းစဉ်ဓာတ်ပုံကိုပြုပြင်ပါ` button.
     - Coin and sycee balance displays.
     - Editable nickname with pencil icon.
     - ID and Account Name with `ကူးယူပါ` (Copy) buttons.
     - VIP 1 emblem with `VIP အကျိုးကျေးဇူးများ`.
     - `အကောင့်ချိတ်ပါ` (Bind Account) and `ဂိမ်းကနေထွက်လိုက်ပါ` (Exit) buttons.
   - **Deposit Demo (Screenshots 7, 8, 10, 11)**:
     - KBZ Pay and WavePay method selection.
     - Quick amount grid (2K, 5K, 10K, 30K, 50K, 100K, 200K, 500K).
     - Payment transfer screen with receiver name, account number, receipt 5 digits, payer name, and cancel/confirm buttons.
     - Instant notification alert popup (3-minute automated review notice).
   - **Withdraw Demo (Screenshots 5, 6, 9)**:
     - Bank Card tab, balance display, transaction history shortcut button.
     - Bound bank number display and bind button.
     - Amount slider with gold coin knob, max amount button, and clear amount button.
   - **Bank Account Binding (Screenshots 1, 2, 3, 8b)**:
     - Bank dropdown selector (KBZ Pay / WAVE Pay), account number field, debit card warning notice.
   - **Transaction History (Screenshot 12)**:
     - Authentic red and gold table with Bank Type, Transaction ID, Amount, Timestamp, Status, and Details action button.
     - Pagination (`နောက်စာမျက်နှာ` / `ရှေ့စာမျက်နှာ`) with golden lion statues.
   - **Settings (Screenshot 5b)**:
     - Dark cyan patterned modal with gold coin toggle switches for Music (`တေးသီချင်း`), Sound FX (`တေးသံ`), Special Effects (`အထူးသက်ရောက်မှု`), and Announcements (`ကြေငြာချက်`).
     - Version `v:1.0.113`.
     - Admin payment configuration shortcut & Reset Demo button.
   - **24hr Customer Service Chat (Screenshot 15)**:
     - FAQ, Online Customer Service, and Feedback tabs.
     - Live demo chat messages with timestamp and text reply simulation.
     - Bottom text input, photo attachment demo, and send button.
   - **Admin Payment Config (Prompt Requirement 7)**:
     - Edit KBZ Pay and WavePay receiver names and phone numbers; changes update immediately across the deposit demo UI.

## Technology Stack

- **Platform**: Native Android (Kotlin + Jetpack Compose)
- **Design System**: Material 3 with custom Asian Casino Chinese temple roof architecture
- **Font / Localization**: Pure Myanmar Unicode (Zawgyi-free, standardized rendering)
- **Storage**: Offline local persistence via Android `SharedPreferences`
- **Orientation**: Optimized for landscape mobile gaming

## Build & Run Instructions

### 1. In Android Studio
1. Open Android Studio.
2. Select **Open** and select the project root directory.
3. Allow Gradle to sync.
4. Run on an Android device or emulator with API 24+ in landscape mode.

### 2. Using Gradle via Terminal
```bash
# Run unit tests
gradle :app:testDebugUnitTest

# Build debug APK
gradle :app:assembleDebug
```
The generated APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`
